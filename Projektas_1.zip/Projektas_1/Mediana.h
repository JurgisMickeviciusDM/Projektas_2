#ifndef Mediana_h
#define Mediana_h

#include <vector>

double calculateMedian(const std::vector<int>& grades);

#endif