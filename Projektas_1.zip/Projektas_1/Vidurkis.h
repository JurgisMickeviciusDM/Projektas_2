#pragma once
#include <vector>

double calculateVidurkis(const std::vector<int>& nums);